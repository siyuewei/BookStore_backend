package com.example.bookstores.util.request.CartForm;

public class DeleteCartItemForm {
}
