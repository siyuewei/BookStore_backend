package com.example.bookstores;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoresApplicationTests {

    @Test
    void contextLoads() {
    }

}
