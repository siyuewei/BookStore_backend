package com.example.bookstores.service.Impl;

import com.example.bookstores.dao.BookDao;
import com.example.bookstores.dao.TagDao;
import com.example.bookstores.entity.Book;
import com.example.bookstores.entity.Tag;
import com.example.bookstores.service.BookService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class BookServiceImpl implements BookService {
    private final BookDao bookDao;

    public BookServiceImpl(BookDao bookDao) {
        this.bookDao = bookDao;
    }

    @Override
    public Book getBookById(Long id) {
        return bookDao.findBookById(id).orElseThrow();
    }

    @Override
    public Book getBookByAuthor(String author) {
        return bookDao.findBookByAuthor(author);
    }

    @Override
    public List<Book> getBooks() {
        return bookDao.getBooks();
    }

    @Override
    public void updateBook(Book book) {
        bookDao.updateBook(book);
    }

    @Override
    public void deleteBook(Long id) {
        bookDao.deleteBook(id);
    }

    @Override
    public void addBook(Book book) {
        bookDao.addBook(book);
    }


}
