package com.example.bookstores.service;

import com.example.bookstores.entity.Book;

import java.util.List;

public interface BookService {
    Book getBookById(Long id);

    Book getBookByAuthor(String author);

    List<Book> getBooks();

    void updateBook(Book book);

    void deleteBook(Long id);

    void addBook(Book book);
}
