package com.example.bookstores.util.request.OrderForm;

import com.example.bookstores.entity.Order;

public class GetOrderForm {
    private Order[] orders;
    private String username;


 }
