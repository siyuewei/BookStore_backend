package com.example.bookstores.controller;


import com.example.bookstores.entity.User;
import com.example.bookstores.repository.UserRepository;
import com.example.bookstores.service.UserService;
import com.example.bookstores.util.request.UserForm.AddUserForm;
import com.example.bookstores.util.request.UserForm.UpdateUserForm;
import jakarta.transaction.Transactional;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@Transactional
public class UserController {
//
    @Autowired
    UserService userService;

    @RequestMapping(value = "api/user/checkUser",method = RequestMethod.GET)
    @CrossOrigin(origins = "http://localhost:3000")
    public User checkUser(@RequestParam("username") String username, @RequestParam("password") String password){
        return userService.checkUser(username,password);
    }

    @RequestMapping(value = "api/user/add",method = RequestMethod.POST)
    @CrossOrigin(origins = "http://localhost:3000")
    public boolean addUser(@RequestBody @NotNull AddUserForm addUserForm){
        return userService.addUser(addUserForm);
    }

    @RequestMapping(value = "api/user/update",method = RequestMethod.POST)
    @CrossOrigin(origins = "http://localhost:3000")
    public void updateUser(@RequestBody @NotNull UpdateUserForm updateUserForm){
        userService.updateUser(updateUserForm);
    }

    @RequestMapping(value = "api/user/getAll",method = RequestMethod.GET)
    @CrossOrigin(origins = "http://localhost:3000")
    public Set<User> getAllUser(){
        return userService.getAllUser();
    }

    @RequestMapping(value = "api/user/changeStatus",method = RequestMethod.POST)
    @CrossOrigin(origins = "http://localhost:3000")
    public void changeState(@RequestParam("username") String username, @RequestParam("status") boolean status){
        userService.changeState(username,status);
    }
}
