package com.example.bookstores.controller;

import com.example.bookstores.entity.Book;
import com.example.bookstores.service.BookService;
import jakarta.transaction.Transactional;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Transactional
public class BookController {
    private final BookService bookService;

    public BookController(BookService bookService) {
        this.bookService = bookService;
    }

    @RequestMapping(value = "api/book/{id}",method = RequestMethod.GET)
    @CrossOrigin(origins = "http://localhost:3000")
    Book getBookById(@PathVariable Long id){
        return bookService.getBookById(id);
    }

    @RequestMapping(value = "api/book/author/{author}",method = RequestMethod.GET)
    Book getBookByAuthor(@PathVariable String author){
        return bookService.getBookByAuthor(author);
    }

    @RequestMapping(value = "api/book/add",method = RequestMethod.POST)
    @CrossOrigin(origins = "http://localhost:3000")
    void addBook(@RequestBody Book book){
        bookService.addBook(book);
    }

    @RequestMapping(value = "api/book/get",method = RequestMethod.GET)
    @CrossOrigin(origins = "http://localhost:3000")
    List<Book> getAllBooks(){
        return bookService.getBooks();
    }

    @RequestMapping(value = "api/book/update",method = RequestMethod.POST)
    @CrossOrigin(origins = "http://localhost:3000")
    void updateBook(@RequestBody @NotNull Book book){
        bookService.updateBook(book);
    }

    @RequestMapping(value = "api/book/delete/{id}",method = RequestMethod.DELETE)
    @CrossOrigin(origins = "http://localhost:3000")
    void deleteBook(@PathVariable Long id){
        bookService.deleteBook(id);
    }

}
