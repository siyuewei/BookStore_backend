package com.example.bookstores;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookstoresApplication {

    public static void main(String[] args) {
        SpringApplication.run(BookstoresApplication.class, args);
    }

}
